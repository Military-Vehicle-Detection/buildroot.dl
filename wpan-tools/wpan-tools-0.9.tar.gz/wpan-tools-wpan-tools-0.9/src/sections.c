#include "iwpan.h"

SECTION(get);
SECTION(set);

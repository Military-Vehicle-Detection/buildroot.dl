/*
 * GStreamer
 * Copyright (C) 2006 Stefan Kost <ensonic@users.sf.net>
 * Copyright (C) 2016 Enrico Scholz <enrico.scholz@sigma-chemnitz.de>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#ifndef __GST_BAYER2RGBNEON_H__
#define __GST_BAYER2RGBNEON_H__

#include <stdbool.h>

#include <gst/gst.h>
#include <gst/base/gstbasetransform.h>

G_BEGIN_DECLS

#define GST_TYPE_BAYER2RGBNEON			\
	(gst_bayer2rgbneon_get_type())
#define GST_BAYER2RGBNEON(obj)						\
	(G_TYPE_CHECK_INSTANCE_CAST((obj),GST_TYPE_BAYER2RGBNEON,struct bayer2rgbneon))
#define GST_BAYER2RGBNEON_CLASS(klass)					\
	(G_TYPE_CHECK_CLASS_CAST((klass),GST_TYPE_BAYER2RGBNEON,struct bayer2rgbneon_class))
#define GST_IS_BAYER2RGBNEON(obj)					\
	(G_TYPE_CHECK_INSTANCE_TYPE((obj),GST_TYPE_BAYER2RGBNEON))
#define GST_IS_BAYER2RGBNEON_CLASS(klass)				\
	(G_TYPE_CHECK_CLASS_TYPE((klass),GST_TYPE_BAYER2RGBNEON))

struct bayer2rgbneon {
	GstBaseTransform		element;

	bool				silent;
	bool				show_fps;
	bool				info_shown;
	bool				reduce_bpp;
	unsigned long			quality;
	struct timespec			last_fps_tm;
	unsigned long			frame_cnt;
	int64_t				conv_tm;

	struct {
		unsigned int		bpp;
		unsigned int		format;
		unsigned int		width;
		unsigned int		height;
		unsigned int		stride;
		unsigned int		endian;
	}				in;

	struct {
		unsigned int		bpp;
		unsigned int		format;
		unsigned int		width;
		unsigned int		height;
		unsigned int		stride;

		/* TODO: this is ugly; we should use a typed enum in the
		 * bayer2rgb library for the RGB_FMT_xxx type. */
		int			type;
	}				out;

	void				*bpp_convert_buf;

};

struct bayer2rgbneon_class {
	GstBaseTransformClass		parent_class;
};

GType gst_bayer2rgbneon_get_type (void);

G_END_DECLS

#endif /* __GST_BAYER2RGBNEON_H__ */

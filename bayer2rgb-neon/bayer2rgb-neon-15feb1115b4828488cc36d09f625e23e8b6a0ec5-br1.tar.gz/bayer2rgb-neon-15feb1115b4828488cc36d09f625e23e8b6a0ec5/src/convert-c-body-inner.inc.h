#if 0
void convert_c(struct image_in const *input,
	       struct image_out const *output)
#endif
{

	if (!_round_2 && !_round_4) {
		bool const	round_2 = false;
		bool const	round_4 = false;
#include CONVERT_BODY
	} else if (!_round_2 && _round_4) {
		bool const	round_2 = false;
		bool const	round_4 = true;
#include CONVERT_BODY
	} else {
		bool const	round_2 = _round_2;
		bool const	round_4 = _round_4;
#include CONVERT_BODY
	}
}

/*	--*- c -*--
 * Copyright (C) 2016 Enrico Scholz <enrico.scholz@sigma-chemnitz.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 3 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef H_ENSC_BAYER_COMPILER_H
#define H_ENSC_BAYER_COMPILER_H

#define _noinline_	__attribute__((__noinline__))
#define _always_inline_	__attribute__((__always_inline__))

#define ARRAY_SIZE(_a)	(sizeof(_a) / sizeof(_a)[0])

#define barrier()               do {            \
                __asm__("" ::: "memory");       \
        } while (0==1)

#define offsetof(TYPE, MEMBER)  __builtin_offsetof (TYPE, MEMBER)

#ifndef DEBUG
#  define __do_die(_code)			\
	do {					\
                __builtin_trap();               \
        } while (1 == 1)
#elif defined(__arm__)
#  define __do_die(_code)					\
	do {							\
		__asm__ __volatile__ ("bkpt %0\n"		\
				      : : "I"((_code) % 256)	\
				      : "memory");		\
		__builtin_unreachable();			\
	} while (1 == 1)
#else
#  define __do_die(_code) do {                  \
                __builtin_trap();               \
        } while (1 == 1)
#endif

#define BUG()   do {                                                    \
                if (IS_DEBUG_MODE) {                                    \
                        barrier();                                      \
                }                                                       \
                __do_die(IS_DEBUG_MODE ? (int)(__LINE__) : (int)0);     \
		barrier();						\
        } while (!(IS_DEBUG_MODE))

#endif	/* H_ENSC_BAYER_COMPILER_H */

#if 0
void convert_c(struct image_in const *input,
	       struct image_out const *output)
#endif
do {
	rgb_pixel_t	*out = output->data;
	pixel_t const	*in;
	size_t		stride;
	size_t		out_stride;

	if (input->type != BAYER_GBRG)
		/* TODO */
		abort();

	if (input->info.bpp != 8 * sizeof *in)
		/* TODO */
		break;

	out_stride = output->info.stride / sizeof *out;
	stride	   = input->info.stride  / sizeof *in;

	/* move input to (2,2) pixel */
	in  = input->data;
	in += border * stride;
	in += border;

	for (size_t y = border; y+border < input->info.h; y += 2) {
		rgb_pixel_t	*out_next = out + 2 * out_stride;

		unsigned int	red_delta  = in[-stride] + in[+stride];

		/* skip 2 columns left and 2 columns right */
		for (size_t x = border; x+border < input->info.w; x += 2) {
			unsigned int	red_next = in[-stride+2] + in[+stride+2];
			unsigned int	blue_delta = in[-1] + in[+1];

			do_prefetch(&in[-1*stride-1], 0);
			do_prefetch(&in[ 0*stride-1], 0);
			do_prefetch(&in[+1*stride-1], 0);
			do_prefetch(&in[+2*stride-1], 3);

			/* [G]BRG pixel */
			out[0] = (rgb_pixel_t) {
				.r = avg2(round_2, max_rb, sft_rb, red_delta),
				.b = avg2(round_2, max_rb, sft_rb, blue_delta),
				.g = avg1(max_g, sft_g, in[0]),
			};

			/* G[B]RG pixel */
			out[1] = (rgb_pixel_t) {
				.r = avg4(round_4,  max_rb, sft_rb,
					  red_delta + red_next),
				.b = avg1(max_rb, sft_rb, in[1]),
				.g = avg4(round_4, max_g, sft_g,
					  in[0] + in[+2] +
					  in[-stride + 1] +
					  in[+stride + 1]),
			};

			/* GB[R]G pixel */
			out[out_stride] = (rgb_pixel_t) {
				.r = avg1(max_rb, sft_rb, in[stride]),
				.b = avg4(round_4, max_rb, sft_rb,
					  blue_delta +
					  in[2 * stride - 1] +
					  in[2 * stride + 1]),
				.g = avg4(round_4, max_g, sft_g,
					  in[0] +
					  in[2 * stride] +
					  in[stride - 1] +
					  in[stride + 1]),
			};

			/* GBR[G] pixel */
			out[out_stride+1] = (rgb_pixel_t) {
				.r = avg2(round_2, max_rb, sft_rb,
					  in[+stride] + in[stride+2]),
				.b = avg2(round_2, max_rb, sft_rb,
					  in[+1] + in[2 * stride+1]),
				.g = avg1(max_g, sft_g, in[stride+1]),
			};

			out += 2;
			in  += 2;

			red_delta = red_next;
		}

		out  = out_next;
		in  += stride + 2*border;
	}

	if (info)
		info->fn = __func__;

	handled = 1;
} while (0);

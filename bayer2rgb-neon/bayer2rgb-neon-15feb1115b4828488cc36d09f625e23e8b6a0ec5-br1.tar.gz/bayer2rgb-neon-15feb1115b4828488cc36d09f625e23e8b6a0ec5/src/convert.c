/*	--*- c -*--
 * Copyright (C) 2016 Enrico Scholz <enrico.scholz@sigma-chemnitz.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 3 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdbool.h>
#include <assert.h>
#include "bayer2rgb.h"

static bool have_neon()
{
#ifdef HAVE_NEON
	return true;
#else
	return false;
#endif
}

static bool have_cplusplus()
{
#ifdef HAVE_CPLUSPLUS
	return true;
#else
	return false;
#endif
}

void bayer2rgb_convert_dumb(struct image_in const *input,
			    struct image_out const *output,
			    struct image_conversion_info *info)
{
	extern void __bayer2rgb_missing_convert_dumb_implementation();

	if (have_cplusplus())
		return bayer2rgb_convert_cc(input, output, info);
	else
		__bayer2rgb_missing_convert_dumb_implementation();
}

void bayer2rgb_convert(struct image_in const *input,
		       struct image_out const *output,
		       struct image_conversion_info *info)
{
	bool		allow_accel = !(output->quality &
					(1ul << QUALITY_NO_ACCEL));

	if (info)
		*info = (struct image_conversion_info) { };

	if (have_neon() && allow_accel)
		bayer2rgb_convert_neon(input, output, info);
	else
		bayer2rgb_convert_c_opt(input, output, info);
}

bool bayer2rgb_reduce_bpp(struct image_info *image,
			  void const *in, void *out, unsigned int out_bpp,
			  struct image_conversion_info *info)
{
	return bayer2rgb_reduce_bpp_cc(image, in, out, out_bpp, info);
}

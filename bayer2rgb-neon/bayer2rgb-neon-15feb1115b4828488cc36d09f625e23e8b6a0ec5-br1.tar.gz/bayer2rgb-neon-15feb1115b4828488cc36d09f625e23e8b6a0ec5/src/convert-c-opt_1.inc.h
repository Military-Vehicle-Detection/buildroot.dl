#if 0
void convert_c(struct image_in const *input,
	       struct image_out const *output)
{
#endif
	rgb_pixel_t	*out = output->data;
	pixel_t const	*in;
	size_t		stride;
	size_t		out_stride;

	{
		pixel_t		tmp[4] = { 1, 2, (pixel_t)(~0u), 4 };
		pixel4_t	row;

		read_row(&row, tmp);

		for (size_t i = 0; i < 4; ++i) {
			if (get_col(row, i) != tmp[i])
				abort();
		}
	}

	if (input->type != BAYER_GRBG)
		/* TODO */
		abort();

	if (input->info.bpp != 8 * sizeof *in)
		abort();

	out_stride = output->info.stride / sizeof *out;
	stride	   = input->info.stride  / sizeof *in;

	/* move input to (2,2) pixel */
	in  = input->data;
	in += border * stride;
	in += border;

	for (size_t y = border; y+border < input->info.h; y += 2) {
		rgb_pixel_t	*out_next = out + 2 * out_stride;
		unsigned int	red_delta  = in[-stride] + in[+stride];

		/* skip 2 columns left and 2 columns right */
		for (size_t x = border; x+border < input->info.w; x += 2) {
			pixel4_t	rowp;
			pixel4_t	row0;
			pixel4_t	row1;
			pixel4_t	rown;

			unsigned int	red_next;
			unsigned int	blue_delta;

			read_row(&rowp, &in[-1*stride-1]);
			read_row(&row0, &in[-0*stride-1]);
			read_row(&row1, &in[+1*stride-1]);
			read_row(&rown, &in[+2*stride-1]);

			red_next   = get_col(rowp, 3) + get_col(row1, 3);
			blue_delta = get_col(row0, 0) + get_col(row0, 2);

			/* [G]BRG pixel */
			out[0] = (rgb_pixel_t) {
				.r = avg2(round_2, max_rb, sft_rb, red_delta),
				.b = avg2(round_2, max_rb, sft_rb, blue_delta),
				.g = avg1(max_g, sft_g, get_col(row0, 1)),
			};

			/* G[B]RG pixel */
			out[1] = (rgb_pixel_t) {
				.r = avg4(round_4,  max_rb, sft_rb,
					  red_delta + red_next),
				.b = avg1(max_rb, sft_rb, get_col(row0, 2)),
				.g = avg4(round_4, max_g, sft_g,
					  get_col(row0, 1) + get_col(row0, 3) +
					  get_col(rowp, 2) + get_col(row1, 2)),
			};

			/* GB[R]G pixel */
			out[out_stride] = (rgb_pixel_t) {
				.r = avg1(max_rb, sft_rb, get_col(row1, 1)),
				.b = avg4(round_4, max_rb, sft_rb,
					  blue_delta +
					  get_col(rown, 0) + get_col(rown, 2)),
				.g = avg4(round_4, max_g, sft_g,
					  get_col(row0, 1) + get_col(rown, 1) +
					  get_col(row1, 0) + get_col(row1, 2)),
			};

			/* GBR[G] pixel */
			out[out_stride+1] = (rgb_pixel_t) {
				.r = avg2(round_2, max_rb, sft_rb,
					  get_col(row1, 1) + get_col(row1, 3)),
				.b = avg2(round_2, max_rb, sft_rb,
					  get_col(row0, 2) + get_col(rown, 2)),
				.g = avg1(max_g, sft_g, get_col(row1, 2)),
			};

			out += 2;
			in  += 2;

			red_delta = red_next;
		}

		out  = out_next;
		in  += stride + 2*border;
	}
#if 0
}
#endif

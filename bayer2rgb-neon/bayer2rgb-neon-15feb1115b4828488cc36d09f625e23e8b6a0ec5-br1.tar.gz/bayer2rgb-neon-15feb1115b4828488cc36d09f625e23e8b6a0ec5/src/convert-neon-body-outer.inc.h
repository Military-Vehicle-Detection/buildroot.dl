#if 0
void convert_neon(struct image_in const * __restrict__ input,
		  struct image_out const * __restrict__ output)
#endif
do {
	rgb_pixel_t	* __restrict__ out = output->data;
	pixel_t const	* __restrict__ in;
	size_t		stride;
	size_t		out_stride;

	unsigned int	row_cnt;
	unsigned int	col_cnt;

	if (input->info.bpp != 8 * sizeof *in)
		/* TOOD */
		break;

	out_stride = output->info.stride / sizeof out[0];
	stride	   = input->info.stride  / sizeof in[0];

	/* move input to (<border>, <border>) pixel */
	in  = input->data;
	in += border * stride;
	in += border;

	row_cnt = (input->info.h - 2*border) / rows_per_loop;
	col_cnt = (input->info.w - 2*border) / 2 / 7;

	for (unsigned int y = row_cnt; y > 0; --y) {
		rgb_pixel_t	*out_next = out + rows_per_loop * out_stride;
		pixel_t const	*in_next  = in  + rows_per_loop * stride;

		for (unsigned int x = col_cnt; x > 0; --x) {
#include CONVERT_BODY
			out += 14;
			in  += 2*7;
		}

		out = out_next;
		in  = in_next;
	}

	if (info)
		info->fn = __func__;

	handled = true;
} while (0);

#undef convert_fn0
#undef convert_fn1

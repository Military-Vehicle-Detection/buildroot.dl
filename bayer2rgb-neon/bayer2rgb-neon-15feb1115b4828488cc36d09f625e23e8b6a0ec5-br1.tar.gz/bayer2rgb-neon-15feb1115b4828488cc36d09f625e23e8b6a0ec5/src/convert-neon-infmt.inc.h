#if 0
void bayer2rgb_convert_neon(struct image_in const * __restrict__ input,
			    struct image_out const * __restrict__ output,
			    struct image_conversion_info *info)
#endif
{
	switch (input->info.bpp) {
	case 8: {
		typedef uint8_t		pixel_t;
#define CONVERT_BODY	"convert-neon-body-bayer8.inc.h"

		switch (input->type) {
		case BAYER_GBRG:

#define convert_fn0	convert_pixel_gb8_rgb32
#define convert_fn1	convert_pixel_rg8_rgb32

#include "convert-neon-body-outer.inc.h"

			break;

		case BAYER_RGGB:

#define convert_fn0	convert_pixel_rg8_rgb32
#define convert_fn1	convert_pixel_gb8_rgb32

#include "convert-neon-body-outer.inc.h"

			break;

		case BAYER_BGGR:

#define convert_fn0	convert_pixel_bg8_rgb32
#define convert_fn1	convert_pixel_gr8_rgb32

#include "convert-neon-body-outer.inc.h"

			break;

		case BAYER_GRBG:

#define convert_fn0	convert_pixel_gr8_rgb32
#define convert_fn1	convert_pixel_bg8_rgb32

#include "convert-neon-body-outer.inc.h"

			break;

		default:
			abort();
		}
		break;
#undef CONVERT_BODY
	}

	default:
		set_fallback_reason(info, "neon: unsupported input bpp");
		/* TODO: handle other input sizes */
		break;
	}
}

#if 0
void convert_c(struct image_in const *input,
	       struct image_out const *output)
#endif
{
	bool	_round_2 = output->quality & (1 << QUALITY_ROUND_2);
	bool	_round_4 = output->quality & (1 << QUALITY_ROUND_4);

	switch (output->info.bpp) {
	case 32: {
		typedef struct rgbx32_pixel	rgb_pixel_t;
		unsigned int const		max_rb = 255;
		unsigned int const		max_g  = 255;


		switch (input->info.bpp) {
		case 8: {
			typedef uint8_t		pixel_t;
			typedef uint32_t	pixel4_t;
			unsigned int const	sft_rb = 0;
			unsigned int const	sft_g  = 0;

#include "convert-c-body-inner.inc.h"

			break;
		}
		default:
			set_fallback_reason(info, "c: unsupported input bpp (#0)");
			/* TODO: implement other input bpp */
			handled = 0;
			break;
		}

		break;
	}

	case 16: {
		typedef struct rgb16_pixel	rgb_pixel_t;
		unsigned int const		max_rb = 31;
		unsigned int const		max_g  = 63;


		switch (input->info.bpp) {
		case 8: {
			typedef uint8_t		pixel_t;
			typedef uint32_t	pixel4_t;
			unsigned int const	sft_rb = 3;
			unsigned int const	sft_g  = 2;

#include "convert-c-body-inner.inc.h"

			break;
		}
		default:
			set_fallback_reason(info, "c: unsupported input bpp (#1)");
			/* TODO: implement other input bpp */
			handled = 0;
			break;
		}

		break;
	}

	default:
		set_fallback_reason(info, "c: unsupported output bpp");
		/* TODO: implement other output bpp */
		handled = 0;
		break;
	}

	if (handled == -1)
		/* --> some case was uncatched */
		abort();
}

#undef conv_fn_00
#undef conv_fn_01
#undef conv_fn_10
#undef conv_fn_11

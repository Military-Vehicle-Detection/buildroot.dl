#include "catch_interfaces_runner.h"

namespace Catch {
    IRunner::~IRunner() = default;
}
